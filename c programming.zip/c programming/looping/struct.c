#include<stdio.h>
struct point
{
	int x;
	int y;
};
int main()
{
	struct point p1;
	p1.x=5;
	p1.y=10;
	
	printf("Point coordinates:(%d,%d)\n",p1.x,p1.y);
	return 0;
}


