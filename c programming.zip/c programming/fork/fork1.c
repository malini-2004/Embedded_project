#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

int main()
{
	pid_t cpid;
	cpid =fork();
	if(cpid ==0)
		printf("hello i am child\n");
	else
		printf("hello i am parent\n");
	return 0;
}

