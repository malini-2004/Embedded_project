#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();

    if (pid > 0) {
        
        printf("Parent process (PID: %d) sleeping while child becomes a zombie...\n", getpid());
        sleep(10);
        printf("Parent exiting now.\n");
    } else if (pid == 0) {
       
        printf("Child process (PID: %d) exiting immediately.\n", getpid());
        exit(0); 
    } else {
        printf("Fork failed.\n");
        return 1;
    }

    return 0;
}

