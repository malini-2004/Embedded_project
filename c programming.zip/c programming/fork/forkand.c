#include<stdio.h>
#include<unistd.h>
int main()

{
	if (fork () && fork ())

         	printf("Hello");

	return 0;
}
