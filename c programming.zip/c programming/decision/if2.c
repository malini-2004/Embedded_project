#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter the 3 number:\r\n");
	scanf("%d%d%d",&a,&b,&c);
	if(a<=b)
	{
		if(a<=c)
		{
			printf("a is the smallest number");
		}
		else
		{
			printf("c is not the smallest number");
		}
	}
	else
	{
		if(b<=c)
		{
			printf("b is the number");
		}
		else
		{
			printf("c is the smallest number");
		}
	}

return 0;
}

		


