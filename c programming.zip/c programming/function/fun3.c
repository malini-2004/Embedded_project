#include<stdio.h>
void main()
{
        int n,j,i;
        printf("Enter n values:");
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
           for(j=0;j<=i+1;j++)
              printf("* ");
           printf("\n");
        }
}

