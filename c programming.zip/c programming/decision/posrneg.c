#include<stdio.h>
int main()
{
	int num;
	printf("Enter a number:");
	scanf("%d", &num);

	if(num > 0)
	{
		printf("Enter a positive number\n");
	}
	else if (num<0)
	{
		printf("Enter a negative number\n");
	}
	else
	{
		printf("Enter a zero\n");
	}
	return 0;
}
