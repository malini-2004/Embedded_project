#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter a 3 numbers\n:");
	scanf("%d%d%d",&a,&b,&c);
	if(a<b)
	{
		if(a<c)
		{
			printf("c is greatest");
		}
		else
		{
			printf("a is greatest");
		}
	
	}
	else
	{
	if(b<c)
	{
		printf("c is greatest");
	}
	else
	{
		printf("b is greatest");
	}
	}
	return 0;
}


