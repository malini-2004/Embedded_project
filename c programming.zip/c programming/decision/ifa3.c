#include<stdio.h>
int main()
{
	int a,b,c,d;
	printf("Enter the 4 number:");
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(a<b)
	{
		if(a<c)
		{
			if(a<d)
			{
				printf("a is the smallest");
			}
			else
			{
				printf("d is the smallest");
			}
		}
	}
	else
	{
		if(b<c)
		{
			if(b<d)
			{
				printf("b is smallest");
			}
			else
			{
				printf("d is smallest");
			}
		}
	}
	      if(c<d)
	      {
		      printf("c is smaller");
	      }
	      else
	      {
		      printf("d is smallest");
	      }
	      return 0;
}

