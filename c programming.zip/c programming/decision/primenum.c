#include<stdio.h>
int main()
{
	int n,r,flag=0,i;
	printf("Enter a numbers:\n");
	scanf("%d",&n);
	for(i=2;i<n;i++)
	{
		r=n%i;
		if(r==0)
		flag++;
	}
	if (flag==0)
	{
		printf("It is  a prime number");
	}
	else
	{
		printf("It is  not prime number");
	}
	return 0;
}

