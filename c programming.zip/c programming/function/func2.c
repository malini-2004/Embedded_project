#include<stdio.h>
int add(int a,int b);
int main()
{
        int num_1,num_2,result;
        printf("enter any tow numbers");
        scanf("%d%d",&num_1,&num_2);
        result=add(num_1,num_2);
        printf("the sum of %d and %d is:%d\n",num_1,num_2,result);
        return 0;
}
int add(int a,int b)
{
        return a+b;
}

