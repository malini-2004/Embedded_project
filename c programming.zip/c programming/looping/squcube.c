#include<stdio.h>
int main()
{
	int num1= 2, num2 = 4;
	int square= num1 * num1;
	int cube= num2 * num2 * num2;
	{
		printf("square root of%dis%d\n", num1,square);
		printf("cube of%dis%d\n" ,num2,cube);
	}
	return 0;
}

