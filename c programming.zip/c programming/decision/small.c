#include<stdio.h>
int main()
{
	int a,b;
	printf("Enter a 2 numbers:");
	scanf("%d%d",&a,&b);
	if (b<a)
	{
		printf("b is smallest:");
	}
	else
	{
		printf("b is not smallest:");
	}
	return 0;
}


