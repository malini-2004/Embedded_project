#include<stdio.h>
int main()
{
	int a,b,c,d;
	printf("enter a 4 number:");
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(a>b)
	{
		if(a>c)
		{
			if(a>d)
			{
				printf("a is greatest");
			}
			else
			{
				printf("d is the greatest");
			}
		}
	}
	else
	{
		if(b>c)
		{
			if(b>d)
			{
				printf("b is greatest");
			}
			else
			{
				printf("d is greatest");
			}
		}
	}
	if(c>d)
	{
		printf("c is greatest");
	}
	else
	{
		printf("d is greatest");
	}
	return 0;
}




	

