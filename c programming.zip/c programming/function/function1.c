#include<stdio.h>
int main()
{
	int n=3;
	fun(n);
	return 0;
}
void fun(x)
{
	if(x>0)
	{
		printf("%d",x);
		fun(x-1);
	}
	else
		return 0;
}


