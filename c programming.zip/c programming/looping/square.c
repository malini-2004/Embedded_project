#include <stdio.h>

int main() {
    int num1 = 4, num2 = 6;
    int square = num1 * num1;
    int cube1 = num2 * num2 * num2;
    
    printf("Square of %d: %d\n", num1, square);
    printf("Cube of %d: %d\n", num2, cube1);
    return 0;
}

