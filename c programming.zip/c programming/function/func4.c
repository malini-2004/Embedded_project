#include<stdio.h>
#include<stdlip.h>
struct detail{
        char name[10];
        int age;
        char education[50];
	
}st_var;
int main()
{
        struct detail st_var={"MALU",20,"MCA",};

        printf("%s %d %s",st_var.name,st_var.age,st_var.education);
        return 0;
}

