#include <stdio.h>

int main() 
{
	int i;
	i=1;
	for(i=1;1<=5;i++)
		printf("%d karthi\n",i);
	return 0;
}



