#include<stdio.h>
int main()
{
	int a=5,m,b=10;
	printf("a=%d,b=%d\n",a,b);
	m=swap(a,b);
	return 0;
}
void swap(int x,int y);
{
	int temp=x;
	x=y;
	y=temp;
	printf("a=%d,b=%d/n",x,y);
}

