include<stdio.h>
int main()
{
    int a, b, c, d, smallest;

    printf("Enter four numbers: ");
    scanf("%d %d %d %d", &a, &b, &c, &d);

    if (a > b)
    {
        if (b > c)
       	{
            if (c > d)
	    {
                smallest = d;
            }
	    else
	    {
                smallest = c;
          }
        }
       	else
       	{
            if (b > d) 
	    {
                smallest = d;
            }
	    else
	    {
                smallest = b;
            }
        }
    }
    else
    {
        if (a > c)
       	{
            if (c > d)
	    {
                smallest = d;
            }
	    else 
	    {
                smallest = c;
            }
        } 
	else 
	{
            if (a > d)
	    {
                smallest = d;
            }
	    else 
	    {
                smallest = a;
            }
        }
    }

    printf("The smaaller number is:%d\n",smallest);
    return 0;
}
