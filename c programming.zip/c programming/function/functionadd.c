#include<stdio.h>
int main()
{
	void add (void)
	{
		int a=10,b=20,c;
		c=a+b;
		printf("%d",c);
	}
	add();
	return 0;
}


