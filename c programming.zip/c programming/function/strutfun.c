#include<stdio.h>
int main()
{
	struct carmodel
	{
		int carprice;
		int  carnumber;
		int carMaxspeed;
		float carhight;
	};
	int main(void)
	{
		struct carmodel BMW={2001,2200,2305};
		printf("Sizeof carModel %d I64\n"sizeof( strut carmodel));
		getch();
		return 0;
	}
}


