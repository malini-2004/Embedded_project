#include<stdio.h>
int main()
{
        int a=5,m,b=10;
        printf("a=%db=%d\n",a,b);
        m=swap(a,b);
        return 0;
}
void swap(int x,int y);
{
        int temp=x;
        x=y;
        y=temp;
        printf("a=%db=%d/n",x,y);
}

