#include<stdio.h>
int main()
{
	int a,b,greatest;
	printf("Enter 2 numbers:");
	scanf("%d,%d",&a,&b);
	if(a>b)
	{
		printf("a is greatest");
	}
	else
	{
		printf("a is not greatest");
	}
	return 0;
}

