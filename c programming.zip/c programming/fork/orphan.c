#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = fork(); 

    if (pid > 0) {
       
        printf("Parent process exiting. PID: %d\n", getpid());
        exit(0); 
    } else if (pid == 0) {
        
        sleep(5); 
        printf("I am an orphan! My new parent is PID: %d\n", getppid());
    } else {
        printf("Fork failed.\n");
    }

    return 0;
}

