#include<stdio.h>
int main()
{
	int a,b;
	printf("Enter the 2 number:\n\r");
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		printf("a is greatest number");
	}
	else
	{
		printf("a is not a greatest number");
	}
	return 0;
}

